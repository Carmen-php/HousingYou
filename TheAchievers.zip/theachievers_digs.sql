-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `digs`
--

DROP TABLE IF EXISTS `digs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `digs` (
  `digsID` int NOT NULL AUTO_INCREMENT,
  `agentID` int DEFAULT NULL,
  `propertyName` text,
  `propertyPrice` int DEFAULT NULL,
  `propertyAddress` varchar(1000) DEFAULT NULL,
  `agency` text,
  `propertyType` text,
  `numberOfBedrooms` int DEFAULT NULL,
  `propertyStatus` text,
  `propertyParking` text,
  `propertyFurnished` text,
  `numberOfBathrooms` int DEFAULT NULL,
  `propertyDescription` varchar(500) DEFAULT NULL,
  `wifi` int DEFAULT NULL,
  `waterTanks` int DEFAULT NULL,
  `generator` int DEFAULT NULL,
  `prepaidElectricity` int DEFAULT NULL,
  `accreditedAccommodation` int DEFAULT NULL,
  PRIMARY KEY (`digsID`),
  KEY `digs_ibfk_1` (`agentID`),
  CONSTRAINT `digs_ibfk_1` FOREIGN KEY (`agentID`) REFERENCES `agent` (`agentID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digs`
--

LOCK TABLES `digs` WRITE;
/*!40000 ALTER TABLE `digs` DISABLE KEYS */;
INSERT INTO `digs` VALUES (49,26,'The Doves',7000,'1 Huntly, 29 Street, Sunnyside, grahamstown','Oaktree','Apartment',3,'Available','Yes','Yes',3,'This spacious apartment is a walk to campus and all social and shopping amenities.\r\n\r\nThis 3 bedroom ( all with en-suite showers, toilet and basin) unit is an excellent investment and or home from home for your child. Close to Rhodes University. Large living area leading out to a balcony and upmarket kitchen with granite tops.\r\n\r\nIncludes: washing machine, tumble dryer, fridge, elo and hob.\r\n\r\nExtra security at the entrance to the building, Electric fence and undercover parking.',1,1,0,1,1),(50,26,'The Doves',4000,'1 Huntly, 29 Street, Sunnyside, Grahamstown','Oaktree','Apartment',3,'Available','Yes','Yes',3,'This spacious apartment is a walk to campus and all social and shopping amenities.\r\n\r\nThis 3 bedroom ( all with en-suite showers, toilet and basin) unit is an excellent investment and or home from home for your child. Close to Rhodes University. Large living area leading out to a balcony and upmarket kitchen with granite tops.\r\n\r\nIncludes: washing machine, tumble dryer, fridge, elo and hob.\r\n\r\nExtra security at the entrance to the building, Electric fence and undercover parking.',1,1,1,1,1),(51,27,'Little Rose',7000,'113/2018 SS LITTLE ROSE, 4 Rose Street','Pam Golding','Apartment',1,'Available','Yes','Yes',1,'LITTLE ROSE - Located in the center of Grahamstown in Rose Street, just off African street. The apartment offers open plan living, space for a bed, study area and kitchen space with an ensuite bathroom. This fantastic apartment boasts Granite counter-tops, polished porcelain tiles throughout, built-in-cupboards, high-quality sanitaryware and plumbing.\r\n\r\n',1,1,0,1,1),(52,28,'The TAE',3300,'1 Barrydale str, Kingswood, Grahamstown','Pam Golding','Apartment',1,'Available','Yes','No',1,'Two bedrooms offering space and serenity. Two luxurious bathrooms exuding modern elegance. The open plan living area with its warm and inviting wood burning fireplace, creates a cosy and welcoming atmosphere, especially with the panoramic views, perfect for relaxation. Double carport. CCTV\r\n\r\nPlus: A granny flat connected on the main borehole and an additional water tank makes living here a necessity.\r\n\r\n With a number of game roaming around, this is definitely an escape to your serenity.',1,1,0,1,1),(53,28,'Kingswood',3600,'34 Kings Gardens, Kingswood, Grahamstown','Pam Golding','House',2,'Available','Yes','Yes',3,'Situated in 24 hour manned security complex this townhouse is positioned with an elevation affording beautiful views across Grahamstown and a sense of space. Kings Gardens has excellent resale and rental value as it is very multipurpose. It is especially attractive as a lock up and go due to its excellent security, also popular for first time owners, professional singles and couples, as well as a popular rental property.',1,1,0,1,0),(54,28,'The TAE',4500,'2 Short Street','Pam Golding','House',3,'Available','Yes','Yes',1,'This 3 bedroom character cottage plus a self-contained flat is situated across the road from St Andrews College and DSG fields. Property is structurally sound and in need of maintenance (quote available) to return it to its potential.',1,1,0,1,0),(55,28,'Tshivhuya Place',25000,'A','Pam Goldings','Apartment',1,'Available','Yes','Yes',1,'A',0,0,1,0,0),(56,28,'Tshivhuyas Place',25,'A','Pam Goldings','Apartment',1,'Available','Yes','Yes',1,'A',1,0,0,0,0),(57,29,'The Greens',3600,'58 New Street, Grahamstown','Remax','Apartment',2,'Available','Yes','Yes',1,'The Greens - Available 01 December 2023\r\n\r\nThe Greens is a highly sought after complex is ideally situated within 5 minutes walking distance to Rhodes and extremely popular with students.\r\n\r\nThe complex offers access to Peppergrove mall with Pick n Pay, Chemist, Doctors and restaurants. The premises are protected by security guards and CCTV. There is also ample secure parking as well as laundry and braai facilities!\r\n',1,1,0,1,1),(58,31,'Aquitaine Way',4500,'57 Hight Street, Grahamstown','Pam Golding','Apartment',2,'Available','Yes','Yes',1,'A walk in the park away from Rhodes University, Pepper Grove Mall and Spar;\r\n\r\nThis beautiful two bedroom apartment located in the center of Grahamstown compromises of Open plan kitchen and living area, included is washing machine, dryer, 3 x plate gas stove and x 1 electric plate and freezer.\r\n\r\nThe apartment boasts with beautiful marble counter fitted tops and built in cupboards, the bathroom also includes (bathroom, shower, basin and toilet).',1,1,0,1,1),(59,31,'Aquitaine Way',3000,'Grey Street, Grahamstown','Pam Golding','Apartment',1,'Available','Yes','Yes',1,'Cute bachelor flat available to rent close to Rhodes.\r\n\r\nUnit comes with a bar fridge and a 2 place stove, bed\r\n\r\nPre paid electricity and water included.\r\n\r\nThis flat is set in a lovely large garden.\r\n\r\nWater tanks available',1,1,0,1,1);
/*!40000 ALTER TABLE `digs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:30
