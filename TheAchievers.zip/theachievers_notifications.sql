-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `notificationID` int NOT NULL AUTO_INCREMENT,
  `tenantID` int DEFAULT NULL,
  `agentID` int DEFAULT NULL,
  `message` text,
  PRIMARY KEY (`notificationID`),
  KEY `notifications_ibfk_2` (`tenantID`),
  KEY `notifications_ibfk_3` (`agentID`),
  CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`tenantID`) REFERENCES `tenant` (`tenantID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `notifications_ibfk_3` FOREIGN KEY (`agentID`) REFERENCES `agent` (`agentID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (49,37,26,'I would like to view this property please contact me to set an appointment'),(50,38,28,'I would like to view the property'),(51,39,28,'Lovey property. Could we schedule a viewing'),(52,40,26,'Hi when can  set an appointment to view this property'),(53,40,28,'Can we  set an appointment this this Friday?'),(55,37,26,'i want to set an appointment'),(56,37,27,'i want to set an appointment'),(57,39,26,'I would really like to live here.'),(59,39,28,'hi'),(60,39,28,'hi'),(61,48,26,'May I please see this ma\'am'),(62,40,31,'I love this property can I please set up a meeting to view the property'),(63,49,27,'I would like to live here.'),(64,49,31,'This place looks lovely, may I have a tour?'),(65,39,26,'i want to live here'),(66,39,26,'i want to live here'),(67,39,26,'i want to live here'),(68,39,26,'i want to live here'),(69,39,26,'i want to live here'),(70,39,26,'i want to live here'),(71,39,26,'i want to live here'),(72,39,26,'i want to live here'),(73,39,26,'I would love to live here.'),(74,39,26,'i want to live here'),(75,39,26,'I would love to live here.'),(76,39,26,'I would love to live here.'),(77,39,26,'I would love to live here.'),(78,51,26,'I want thiss!!!!');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:32
