-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `role` text NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (44,'Carmen','Supervisor','8ca8c1f6c15c2d9b24bcc0fe72f62da51d222b76'),(90,'tshivhu','Supervisor','7c222fb2927d828af22f592134e8932480637c0d'),(91,'TK','Tenant','ed1550eef4680f84fbacde1a932edc46e21fa79e'),(92,'Ziyanda','Tenant','5c39ab8cfefd120bfffc4c0119f77b44b8950d8c'),(93,'Jam','Tenant','0ec0ce817d7f6ea455d44d49f597f9e9eee9f9d5'),(94,'Unam','Tenant','d75d11d3c72567b8f8a0f37afd020873f4c5c91a'),(95,'Lindiwe','Agents','d0fb84333c40b965315a419239e2fbd04f3464f9'),(96,'Rose','Agents','e2e6706f067079a8da6efca56b3b35f7683e052d'),(97,'John','Agents','6d1134b5ad685957e44c4d956590bc9d14ebe21f'),(98,'Luke','Agents','710c3ae0202fb68ea1f4483b444ad2cd6621f5e7'),(99,'Tom','Agents','39031e55dfdef90ffcf00bb654c62b61386ac110'),(100,'Ingrid','Agents','6913b4633b429b2f797e8374f2985f5c01f453f5'),(101,'judimb19','Tenant','6f78f687955cdf788824191c5529e689eee9b097'),(102,'marychipa2','Tenant','c0ea2a8f35ad76c5ba4c98899f6026bb13d7c5a5'),(103,'nick','Tenant','279d5aeaa972af418d859e8802b7bb7d2d45d416'),(104,'Lindi','Tenant','ad3a0a45848fe27e905f8c7f13e8f019e834ef72'),(105,'Tom','Tenant','39031e55dfdef90ffcf00bb654c62b61386ac110'),(106,'Tom','Tenant','39031e55dfdef90ffcf00bb654c62b61386ac110'),(107,'Andy','Tenant','9e4c273fdd0871527dedd6b69c77dfdbf1492520'),(108,'Ruby','Tenant','f7c3bc1d808e04732adf679965ccc34ca7ae3441'),(109,'tshivhuya','Tenant','24814f5138dc454f789fb62d6d77d00b9cc441fd'),(110,'alice','Tenant','f0bd251b08338c230d420f33106faf13a12cace5'),(111,'Bill','Tenant','942b993ce6fc6af9cf40671a79f9b0f2e1e3d6da');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:38
