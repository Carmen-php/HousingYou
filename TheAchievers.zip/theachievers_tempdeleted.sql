-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tempdeleted`
--

DROP TABLE IF EXISTS `tempdeleted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tempdeleted` (
  `tempdeletedID` int NOT NULL AUTO_INCREMENT,
  `photographID` int NOT NULL,
  `digsID` int DEFAULT NULL,
  `pname` varchar(500) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tempdeletedID`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempdeleted`
--

LOCK TABLES `tempdeleted` WRITE;
/*!40000 ALTER TABLE `tempdeleted` DISABLE KEYS */;
INSERT INTO `tempdeleted` VALUES (20,87,51,'1696554138_2_ffb94ca4-5247-dd0b-731c-132dcbfffebc.jpg',0),(21,85,51,'1696554138_0_55b1bbca-f191-080a-be46-9491c5601f5d.jpg',0),(22,86,51,'1696554138_1_834ce47c-b2df-6de3-cb9a-e5e2b4c1fe5b.jpg',0),(23,89,52,'1696556043_0_house.jpg',0),(24,90,52,'1696556043_1_house2.jpg',0),(25,91,52,'1696556043_2_house3.jpg',0),(26,91,52,'1696556043_2_house3.jpg',0),(27,91,52,'1696556043_2_house3.jpg',0),(28,91,52,'1696556043_2_house3.jpg',0),(29,91,52,'1696556043_2_house3.jpg',0),(30,91,52,'1696556043_2_house3.jpg',0),(31,92,52,'1696556043_3_housefront.jpg',0),(32,93,53,'1696556366_0_kingswood.jpg',0),(33,93,53,'1696556366_0_kingswood.jpg',0),(34,93,53,'1696556366_0_kingswood.jpg',0),(35,92,52,'1696556043_3_housefront.jpg',0),(36,92,52,'1696556043_3_housefront.jpg',0),(37,94,53,'1696556366_1_kingswood2.jpg',0),(38,94,53,'1696556366_1_kingswood2.jpg',0),(39,94,53,'1696556366_1_kingswood2.jpg',0),(40,94,53,'1696556366_1_kingswood2.jpg',0),(41,94,53,'1696556366_1_kingswood2.jpg',0),(48,95,53,'1696556366_2_kingswoodfront.jpeg',0),(51,94,53,'1696556366_1_kingswood2.jpg',0),(52,96,54,'1696556599_0_ramdonfront.jpg',0),(53,97,54,'1696556599_1_random2.jpg',0),(59,99,55,'1696967264_0_Dovesfrontnew.jpg',0),(69,98,54,'1696556599_2_random3.jpg',0),(70,98,54,'1696556599_2_random3.jpg',0),(71,98,54,'1696556599_2_random3.jpg',0),(72,98,54,'1696556599_2_random3.jpg',0),(73,98,54,'1696556599_2_random3.jpg',0),(74,98,54,'1696556599_2_random3.jpg',0),(75,98,54,'1696556599_2_random3.jpg',0),(76,98,54,'1696556599_2_random3.jpg',0),(77,98,54,'1696556599_2_random3.jpg',0),(79,98,54,'1696556599_2_random3.jpg',0),(80,98,54,'1696556599_2_random3.jpg',0),(81,98,54,'1696556599_2_random3.jpg',0),(82,104,56,'1696967341_0_Dovesfrontnew.jpg',0),(85,104,56,'1696967341_0_Dovesfrontnew.jpg',0),(89,98,54,'1696556599_2_random3.jpg',0),(92,78,49,'1696553100_0_dovekit.jpg',0),(94,80,49,'1696553100_2_dovesliv.jpg',0),(95,82,50,'1696553343_1_Doveskitnew.jpg',0);
/*!40000 ALTER TABLE `tempdeleted` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:33
