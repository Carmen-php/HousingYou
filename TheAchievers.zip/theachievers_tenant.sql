-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `tenantID` int NOT NULL AUTO_INCREMENT,
  `userID` int DEFAULT NULL,
  `name` text,
  `surname` text,
  `phoneNumber` int DEFAULT NULL,
  `emailAddress` varchar(60) DEFAULT NULL,
  `studentNumber` varchar(8) DEFAULT NULL,
  `ipAddress` varchar(15) DEFAULT NULL,
  `rememberMe` tinyint DEFAULT NULL,
  PRIMARY KEY (`tenantID`),
  KEY `tenant_ibfk_1` (`userID`),
  CONSTRAINT `tenant_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
INSERT INTO `tenant` VALUES (37,91,'TK','Lekoma',763256984,'TK@gmail.com','G20L9911','146.231.107.196',1),(38,92,'Ziyanda','Sodiya',792561425,'Ziyanda@gmail.com','G19S1258','146.231.107.196',1),(39,93,'Jam','Kock',795862965,'Jam@gmail.com','G18J1122','146.231.107.196',1),(40,94,'Unam','Gazi',751236954,'Unam@gmail.com','G20G4466','146.231.107.196',1),(41,101,'Judicious','Mbhlati',719631548,'judimb@gmail.com','g19m5678','146.231.107.197',1),(42,102,'Mary','Chipa',731456982,'marychipa@gmail.com','G20N2353','146.231.107.197',0),(43,103,'Nick','Mkansi',736987593,'n.mkansi@gmail.com','g21m5978','146.231.107.197',1),(44,104,'Lindiwe','Gazi',790812148,'car@gmail.com','g20k4997','146.231.107.140',1),(45,105,'Tom','Kock',790121485,'Tom@gmail.com','g20k4997','146.231.107.153',0),(46,106,'Tom','Kock',790212365,'Tom@gmail.com','g20k4997','146.231.122.38',1),(47,107,'Andiswa','Gumede',123456789,'GUM@GMAIL.COM','g20s2952','146.231.11.107',1),(48,108,'Ruby','Rose',825201478,'rubyrose@gmail.com','G34R2345','146.231.107.157',0),(49,109,'Tshivhuya','Netshivhambe',731453519,'tshivhuya@gmail.com','g20n2368','146.231.184.167',1),(50,110,'Alice','White',735819221,'a.white@gmail.om','G20N2368','146.231.184.167',0),(51,111,'bill','gates',987689589,'bill@gmail.com','g20k4997','146.231.70.12',0);
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:36
