-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `photograph`
--

DROP TABLE IF EXISTS `photograph`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photograph` (
  `photographID` int NOT NULL AUTO_INCREMENT,
  `digsID` int DEFAULT NULL,
  `pname` varchar(500) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`photographID`),
  KEY `photograph_ibfk_1` (`digsID`),
  CONSTRAINT `photograph_ibfk_1` FOREIGN KEY (`digsID`) REFERENCES `digs` (`digsID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photograph`
--

LOCK TABLES `photograph` WRITE;
/*!40000 ALTER TABLE `photograph` DISABLE KEYS */;
INSERT INTO `photograph` VALUES (79,49,'1696553100_1_dovesfront.jpg',0),(81,50,'1696553343_0_Dovesfrontnew.jpg',0),(83,50,'1696553343_2_doveskitnew1.jpg',0),(84,50,'1696553343_3_doveskitnew2.jpg',0),(88,51,'1696554138_3_rosefront.jpg',0),(100,55,'1696967264_1_Doveskitnew.jpg',0),(101,55,'1696967264_2_doveskitnew1.jpg',0),(102,55,'1696967264_3_doveskitnew2.jpg',0),(103,55,'1696967264_4_dovesliv.jpg',0),(105,57,'1697011335_0_thegreensbed.jpg',0),(106,57,'1697011335_1_thegreensfront.jpg',0),(107,57,'1697011335_2_thegreenskit.jpg',0),(108,57,'1697011335_3_thegreenssit.jpg',0),(109,58,'1697011846_0_Aqufront.jpg',0),(110,58,'1697011846_1_aqukit.jpg',0),(111,58,'1697011846_2_aqulounge.jpg',0),(112,58,'1697011846_3_aquroom.jpg',0),(113,59,'1697012561_0_Aqufront.jpg',0),(114,59,'1697012561_1_aqukit.jpg',0),(115,59,'1697012561_2_aqulounge.jpg',0),(116,59,'1697012561_3_aquroom.jpg',0);
/*!40000 ALTER TABLE `photograph` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:23
