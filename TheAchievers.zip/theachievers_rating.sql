-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: theachievers
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rating` (
  `ratingID` int NOT NULL AUTO_INCREMENT,
  `digsID` int DEFAULT NULL,
  `tenantID` int DEFAULT NULL,
  `comment` text,
  `location` int DEFAULT NULL,
  `conditionOfApartment` int DEFAULT NULL,
  `valueForMoney` int DEFAULT NULL,
  `maintenance` int DEFAULT NULL,
  `average` decimal(3,2) DEFAULT NULL,
  PRIMARY KEY (`ratingID`),
  KEY `rating_ibfk_1` (`digsID`),
  KEY `rating_ibfk_2` (`tenantID`),
  CONSTRAINT `rating_ibfk_1` FOREIGN KEY (`digsID`) REFERENCES `digs` (`digsID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `rating_ibfk_2` FOREIGN KEY (`tenantID`) REFERENCES `tenant` (`tenantID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` VALUES (90,49,37,'It is a lovely place. I want to live here again',5,5,4,4,4.50),(91,52,39,'It was a lovely stay ',5,3,4,4,4.00),(92,52,39,'It was a great digs to live in ',4,5,4,5,4.50),(93,52,40,'It was a great stay ',4,4,5,5,4.50),(94,49,37,'I loved it',4,5,5,5,4.75),(95,49,37,'Amazing please live here!',5,5,5,5,5.00),(96,49,37,'Please live here you will not regret it',5,5,5,5,5.00),(97,49,37,'Its lovely living here ',4,5,5,5,4.75),(98,52,39,'I love this.',4,4,4,2,3.50),(99,52,39,'Amazing Apartment',4,3,4,3,3.50),(100,52,39,'I love it over here.',2,4,3,4,3.25),(101,52,39,'Overall good',2,4,4,5,3.75),(102,52,39,'there is room for improvement :)',4,4,4,4,4.00),(103,52,39,'more room for improvement',3,4,4,4,3.75),(104,52,39,'please work ',4,5,4,5,4.50),(105,52,39,'take 6',4,3,4,4,3.75),(106,52,39,'take 6',4,3,4,4,3.75),(107,52,39,'please work ',4,5,4,5,4.50),(108,52,39,'',0,0,0,0,0.00),(109,52,39,'',0,0,0,0,0.00),(110,52,39,'',0,0,0,0,0.00),(111,52,39,'',0,0,0,0,0.00),(112,52,39,'',0,0,0,0,0.00),(113,52,39,'take 7',4,5,5,4,4.50),(114,52,39,'take 8',4,1,4,5,3.50),(115,52,39,'',0,0,0,0,0.00),(116,52,39,'',0,0,0,0,0.00),(117,52,39,'take 9',1,1,5,5,3.00),(118,52,39,'Great Place',4,3,3,3,3.25),(119,52,39,'Great Place',5,5,5,5,5.00),(120,52,39,'Great Place',5,5,5,5,5.00),(121,50,48,'The apartment was good to live in. It did what it needed to do.',3,3,4,5,3.75),(122,52,39,'Love it here.',4,5,5,4,4.50),(123,49,37,'Awesome',4,5,5,5,4.75),(124,51,49,'Great place to live, spacious room and inviting community.',4,5,5,4,4.50),(125,52,40,'I love this property. Only problem it is far from campus',4,5,5,5,4.75),(126,51,49,'I love it here, great place for students.',5,5,5,5,5.00),(127,49,51,'I love it here.',3,3,4,5,3.75);
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-20 14:10:22
